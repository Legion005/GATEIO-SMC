# Cara build APK tanpa install Flutter

1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini.
3. Buka tab **Actions**.
4. Pilih workflow **Build Android APK**.
5. Klik **Run workflow**.
6. Tunggu sampai selesai.
7. Buka hasil workflow dan download artifact **gateio-smc-bot-apk**.
8. Extract ZIP artifact dan install `app-release.apk` ke HP.

Flutter resmi mendukung `flutter build apk --release`; dokumentasi resmi juga menjelaskan output APK release dan proses signing untuk distribusi. 
