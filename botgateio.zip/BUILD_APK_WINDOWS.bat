@echo off
setlocal
if not exist flutter_app mkdir flutter_app
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter tidak ditemukan. Install Flutter 3.44+ terlebih dahulu.
  pause
  exit /b 1
)
flutter create --platforms=android --org com.gateio.smc gateio_smc_bot
copy /Y pubspec.yaml gateio_smc_bot\pubspec.yaml >nul
copy /Y app\lib\*.dart gateio_smc_bot\lib\ >nul
python scripts\patch_android.py
cd gateio_smc_bot
flutter pub get
flutter build apk --release
if errorlevel 1 (
  echo BUILD GAGAL.
  pause
  exit /b 1
)
echo APK: gateio_smc_bot\build\app\outputs\flutter-apk\app-release.apk
pause
