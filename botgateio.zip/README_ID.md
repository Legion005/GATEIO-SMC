# Gate.io SMC BOT Android — Build Ready

Target: Android APK standalone.

Alur penggunaan:
1. Build APK dengan GitHub Actions atau Flutter di laptop.
2. Install APK ke HP Android.
3. Buat API key Gate.io yang hanya punya izin trading, tanpa withdrawal.
4. Pilih TESTNET terlebih dahulu.
5. SAVE & TEST.
6. START BOT.

## Fitur
- Gate.io Futures USDT perpetual
- SMC 15M proxy: liquidity sweep + BOS + FVG + EMA200
- Risk per posisi 2% equity
- RR 1:3
- Auto BUY/SELL
- Max posisi configurable
- Foreground service + notification
- Secure storage untuk API key/secret

## Penting
Ini adalah build-ready prototype, bukan jaminan sistem trading 24/7. Android 15 memberlakukan batas waktu untuk foreground service `dataSync`, dan vendor Android dapat menerapkan pembatasan baterai tambahan. Untuk 24/7 yang benar-benar konsisten, server/VPS lebih cocok.

Sebelum LIVE, hardening yang masih disarankan: idempotency/duplicate-order protection, position reconciliation setelah restart, verifikasi TP/SL setelah order fill, rate-limit/backoff, contract-size validation per simbol, daily loss limit dan kill switch.
