import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

class GateApi {
  final String key, secret;
  final bool testnet;
  GateApi({required this.key, required this.secret, required this.testnet});

  String get base => testnet
      ? 'https://api-testnet.gateapi.io'
      : 'https://api.gateio.ws';
  String get prefix => '/api/v4';

  String _sha512(String s) => sha512.convert(utf8.encode(s)).toString();

  Map<String,String> _auth(String method,String path,String query,String body) {
    final ts=(DateTime.now().millisecondsSinceEpoch~/1000).toString();
    final payloadHash=_sha512(body);
    final msg='$method\n$prefix$path\n$query\n$payloadHash\n$ts';
    final sign=Hmac(sha512,utf8.encode(secret))
        .convert(utf8.encode(msg)).toString();
    return {
      'Accept':'application/json',
      'Content-Type':'application/json',
      'KEY':key,
      'Timestamp':ts,
      'SIGN':sign,
      'X-Gate-Size-Decimal':'1',
    };
  }

  Future<dynamic> get(String path,{Map<String,String>? q,bool auth=false}) async {
    final query=q==null?'' : q.entries.map((e)=>'${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}').join('&');
    final uri=Uri.parse('$base$prefix$path${query.isEmpty?'':'?$query'}');
    final r=await http.get(uri,headers:auth?_auth('GET',path,query,''):{'Accept':'application/json'})
        .timeout(const Duration(seconds:15));
    if(r.statusCode<200||r.statusCode>=300) throw Exception('Gate ${r.statusCode}: ${r.body}');
    return jsonDecode(r.body);
  }

  Future<dynamic> post(String path,Map<String,dynamic> body) async {
    final raw=jsonEncode(body);
    final r=await http.post(Uri.parse('$base$prefix$path'),
      headers:_auth('POST',path,'',raw),body:raw).timeout(const Duration(seconds:15));
    if(r.statusCode<200||r.statusCode>=300) throw Exception('Gate ${r.statusCode}: ${r.body}');
    return jsonDecode(r.body);
  }

  Future<List<dynamic>> contracts()=>get('/futures/usdt/contracts').then((x)=>List<dynamic>.from(x));
  Future<List<dynamic>> candles(String c)=>get('/futures/usdt/candlesticks',
      q:{'contract':c,'interval':'15m','limit':'220'}).then((x)=>List<dynamic>.from(x));
  Future<Map<String,dynamic>> account()=>get('/futures/usdt/accounts',auth:true).then((x)=>Map<String,dynamic>.from(x));
  Future<List<dynamic>> positions()=>get('/futures/usdt/positions',q:{'holding':'true'},auth:true).then((x)=>List<dynamic>.from(x));

  Future<dynamic> marketEntry({
    required String contract, required int size,
    required double tp, required double sl}) =>
    post('/futures/usdt/orders',{
      'contract':contract,
      'size':size,
      'price':'0',
      'tif':'ioc',
      'action_mode':'FULL',
      'pos_margin_mode':'isolated',
      'tpsl_tp_trigger_price':tp.toString(),
      'tpsl_sl_trigger_price':sl.toString(),
      'text':'t-smc-v2',
    });
}
