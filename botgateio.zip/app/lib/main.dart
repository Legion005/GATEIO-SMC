import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'gate_api.dart';
import 'smc_engine.dart';

final secure=const FlutterSecureStorage();

@pragma('vm:entry-point')
void startCallback()=>FlutterForegroundTask.setTaskHandler(BotTask());

class BotTask extends TaskHandler {
  SMCEngine? engine;
  int busy=0;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    final key=await secure.read(key:'gate_key')??'';
    final secret=await secure.read(key:'gate_secret')??'';
    final testnet=(await secure.read(key:'gate_env')??'TESTNET')=='TESTNET';
    final risk=double.tryParse(await secure.read(key:'risk')??'2')??2;
    final rr=double.tryParse(await secure.read(key:'rr')??'3')??3;
    final maxPos=int.tryParse(await secure.read(key:'max_pos')??'3')??3;
    if(key.isEmpty||secret.isEmpty)return;
    engine=SMCEngine(
      api:GateApi(key:key,secret:secret,testnet:testnet),
      riskPct:risk,rr:rr,maxPositions:maxPos);
    FlutterForegroundTask.updateService(
      notificationTitle:'Gate.io SMC BOT RUNNING',
      notificationText:testnet?'TESTNET • SMC 15M':'LIVE • SMC 15M');
  }

  @override
  void onRepeatEvent(DateTime timestamp) async {
    if(engine==null||busy>0)return;
    busy=1;
    try{
      final result=await engine!.runCycle();
      FlutterForegroundTask.updateService(
        notificationTitle:'Gate.io SMC BOT',
        notificationText:result.length>100?result.substring(0,100):result);
      FlutterForegroundTask.sendDataToMain({'log':result,'ts':timestamp.toIso8601String()});
    }catch(e){
      FlutterForegroundTask.updateService(notificationText:'ENGINE ERROR: $e');
    }finally{busy=0;}
  }

  @override Future<void> onDestroy(DateTime timestamp,bool isTimeout) async {}
  @override void onReceiveData(Object data){}
  @override void onNotificationButtonPressed(String id){
    if(id=='stop')FlutterForegroundTask.stopService();
  }
  @override void onNotificationPressed(){}
  @override void onNotificationDismissed(){}
}

class App extends StatelessWidget{
  const App({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'Gate.io SMC PRO V2',
    theme:ThemeData.dark(useMaterial3:true),home:const Home());
}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_HomeState();}

class _HomeState extends State<Home>{
  final key=TextEditingController(),secret=TextEditingController();
  String env='TESTNET',status='DISCONNECTED',log='Ready';
  double risk=2,rr=3,lev=5,maxPos=3;

  @override void initState(){super.initState();_init();FlutterForegroundTask.addTaskDataCallback(_data);}
  Future<void> _init() async {
    key.text=await secure.read(key:'gate_key')??'';
    secret.text=await secure.read(key:'gate_secret')??'';
    _initFg();
  }
  void _data(Object data){if(!mounted)return;if(data is Map)setState(()=>log='${data['log']??data}');}

  void _initFg(){
    FlutterForegroundTask.init(
      androidNotificationOptions:const AndroidNotificationOptions(
        channelId:'gate_smc',channelName:'Gate.io SMC',
        channelDescription:'Trading bot status',onlyAlertOnce:true),
      iosNotificationOptions:const IOSNotificationOptions(showNotification:false,playSound:false),
      foregroundTaskOptions:ForegroundTaskOptions(
        eventAction:const ForegroundTaskEventAction.repeat(30000),
        autoRunOnBoot:false,autoRunOnMyPackageReplaced:true,
        allowWakeLock:true,allowWifiLock:true));
  }

  Future<void> test()async{
    try{
      final api=GateApi(key:key.text.trim(),secret:secret.text.trim(),testnet:env=='TESTNET');
      await api.contracts();
      await secure.write(key:'gate_key',value:key.text.trim());
      await secure.write(key:'gate_secret',value:secret.text.trim());
      await secure.write(key:'gate_env',value:env);
      await secure.write(key:'risk',value:'$risk');
      await secure.write(key:'rr',value:'$rr');
      await secure.write(key:'max_pos',value:'${maxPos.toInt()}');
      setState(()=>status='CONNECTED');
    }catch(e){setState(()=>log='TEST ERROR: $e');}
  }

  Future<void> start()async{
    await test();
    if(status!='CONNECTED')return;
    final p=await FlutterForegroundTask.requestNotificationPermission();
    if(Platform.isAndroid && p!=NotificationPermission.granted){
      setState(()=>log='Notification permission diperlukan.');return;
    }
    final r=await FlutterForegroundTask.startService(
      serviceId:256,notificationTitle:'Gate.io SMC BOT',
      notificationText:env=='TESTNET'?'TESTNET • STARTING':'LIVE • STARTING',
      notificationButtons:const[NotificationButton(id:'stop',text:'STOP')],
      callback:startCallback);
    setState(()=>status=r is ServiceRequestSuccess?'RUNNING':'ERROR');
  }

  Future<void> stop()async{await FlutterForegroundTask.stopService();setState(()=>status='STOPPED');}

  @override void dispose(){
    FlutterForegroundTask.removeTaskDataCallback(_data);
    key.dispose();secret.dispose();super.dispose();
  }

  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('Gate.io SMC PRO V2')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(
        crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('BOT STATUS'),const SizedBox(height:8),
          Text(status,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),Text(log)]))),
      const SizedBox(height:12),
      TextField(controller:key,decoration:const InputDecoration(labelText:'Gate.io API Key',border:OutlineInputBorder())),
      const SizedBox(height:10),
      TextField(controller:secret,obscureText:true,decoration:const InputDecoration(labelText:'Gate.io API Secret',border:OutlineInputBorder())),
      const SizedBox(height:10),
      DropdownButtonFormField<String>(value:env,decoration:const InputDecoration(labelText:'Environment',border:OutlineInputBorder()),
        items:const[DropdownMenuItem(value:'TESTNET',child:Text('TESTNET')),DropdownMenuItem(value:'LIVE',child:Text('LIVE'))],
        onChanged:(v)=>setState(()=>env=v!)),
      const SizedBox(height:10),
      Text('Risk ${risk.toStringAsFixed(1)}%'),Slider(value:risk,min:.5,max:5,divisions:9,onChanged:(v)=>setState(()=>risk=v)),
      Text('RR 1:${rr.toStringAsFixed(0)}'),Slider(value:rr,min:1,max:5,divisions:8,onChanged:(v)=>setState(()=>rr=v)),
      Text('Leverage ${lev.toInt()}x (parameter reserved for hardening)'),Slider(value:lev,min:1,max:20,divisions:19,onChanged:(v)=>setState(()=>lev=v)),
      Text('Max posisi ${maxPos.toInt()}'),Slider(value:maxPos,min:1,max:10,divisions:9,onChanged:(v)=>setState(()=>maxPos=v)),
      const SizedBox(height:10),
      FilledButton(onPressed:test,child:const Text('SAVE & TEST')),
      const SizedBox(height:8),
      FilledButton(onPressed:status=='RUNNING'?stop:start,child:Text(status=='RUNNING'?'STOP BOT':'START BOT')),
      const SizedBox(height:16),
      const Card(child:Padding(padding:EdgeInsets.all(14),child:Text(
        'SMC 15M: Liquidity Sweep → BOS → FVG → EMA200\\n'
        'Risk 2% equity • RR 1:3 • All active USDT perpetuals\\n'
        'Market entry with Gate TP/SL trigger fields\\n'
        'Foreground notification + automatic service restart on package replacement.')))
    ]));
}
