import 'dart:math';
import 'gate_api.dart';

class TradeSignal {
  final String contract, side;
  final double entry, sl, tp, score;
  final int size;
  TradeSignal(this.contract,this.side,this.entry,this.sl,this.tp,this.score,this.size);
}

class SMCEngine {
  final GateApi api;
  final double riskPct, rr;
  final int maxPositions;
  final Set<String> fired = {};

  SMCEngine({required this.api,this.riskPct=2,this.rr=3,this.maxPositions=3});

  double d(dynamic x)=>double.tryParse('$x')??0;

  double ema(List<double> a,int n){
    if(a.isEmpty)return 0;
    final k=2/(n+1); var e=a.first;
    for(final x in a.skip(1))e=x*k+e*(1-k);
    return e;
  }

  double atr(List<double> o,List<double> h,List<double> l,List<double> c,int n){
    final tr=<double>[];
    for(int i=1;i<c.length;i++){
      tr.add(max(h[i]-l[i],max((h[i]-c[i-1]).abs(),(l[i]-c[i-1]).abs())));
    }
    if(tr.length<n)return 0;
    final z=tr.sublist(tr.length-n);
    return z.reduce((a,b)=>a+b)/z.length;
  }

  TradeSignal? analyze(String contract,List<dynamic> raw,double equity,dynamic meta){
    if(raw.length<205)return null;

    // Gate futures candle format is [timestamp, volume, close, high, low, open, ...].
    final o=<double>[],h=<double>[],l=<double>[],c=<double>[];
    for(final r in raw){
      o.add(d(r[5])); h.add(d(r[3])); l.add(d(r[4])); c.add(d(r[2]));
    }

    // Ignore the newest candle; it may still be forming.
    final n=c.length-1;
    final cl=c.sublist(0,n);
    final eh=ema(cl,200);
    final a=atr(o.sublist(0,n),h.sublist(0,n),l.sublist(0,n),cl,14);
    if(a<=0)return null;

    final i=n-1;
    final ph=h.sublist(i-5,i).reduce(max);
    final pl=l.sublist(i-5,i).reduce(min);
    final bullSweep=l[i]<pl&&c[i]>pl;
    final bearSweep=h[i]>ph&&c[i]<ph;

    final bh=h.sublist(i-3,i).reduce(max);
    final bl=l.sublist(i-3,i).reduce(min);
    final bullBos=c[i]>bh;
    final bearBos=c[i]<bl;

    final bullFvg=h[i-2]<l[i];
    final bearFvg=l[i-2]>h[i];

    final isLong=bullSweep&&bullBos&&bullFvg&&c[i]>eh;
    final isShort=bearSweep&&bearBos&&bearFvg&&c[i]<eh;
    if(!isLong&&!isShort)return null;

    final entry=c[i];
    final sl=isLong?l[i]-a*.25:h[i]+a*.25;
    final r=(entry-sl).abs();
    if(r<=0)return null;
    final tp=isLong?entry+r*rr:entry-r*rr;

    final qm=d(meta['quanto_multiplier']);
    final minSize=max(1,int.tryParse('${meta['order_size_min']??1}')??1);
    if(qm<=0)return null;

    final riskPerContract=r*qm;
    final maxRisk=equity*riskPct/100;
    final size=(maxRisk/riskPerContract).floor();
    if(size<minSize)return null;

    final score=80.0;
    return TradeSignal(contract,isLong?'LONG':'SHORT',entry,sl,tp,score,size);
  }

  Future<String> runCycle() async {
    final acct=await api.account();
    final equity=d(acct['total']);
    final pos=await api.positions();
    if(pos.length>=maxPositions)return 'MAX_POSITIONS';

    final contracts=await api.contracts();
    for(final meta in contracts){
      if(meta['state']!='normal')continue;
      final c='${meta['name']}';
      if(!c.endsWith('_USDT'))continue;
      try{
        final s=analyze(c,await api.candles(c),equity,meta);
        if(s==null)continue;
        final key='$c:${s.side}:${s.entry.toStringAsFixed(8)}';
        if(fired.contains(key))continue;
        fired.add(key);
        final size=s.side=='LONG'?s.size:-s.size;
        await api.marketEntry(contract:c,size:size,tp:s.tp,sl:s.sl);
        return 'OPEN ${s.side} $c size=${s.size} entry=${s.entry} SL=${s.sl} TP=${s.tp}';
      }catch(_){}
    }
    return 'NO_SIGNAL';
  }
}
