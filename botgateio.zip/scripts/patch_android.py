from pathlib import Path
p=Path('gateio_smc_bot/android/app/src/main/AndroidManifest.xml')
s=p.read_text()
s=s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">', '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />\n    <uses-permission android:name="android.permission.WAKE_LOCK" />\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />')
needle='</application>'
service='''    <service\n        android:name="com.pravera.flutter_foreground_task.service.ForegroundService"\n        android:foregroundServiceType="dataSync"\n        android:exported="false" />\n'''
s=s.replace(needle, service+needle)
p.write_text(s)
